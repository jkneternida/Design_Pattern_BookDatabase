package BookDB_design_pattern;

import java.util.HashMap;
import java.util.Map;

public class BookDatabase {
    private static BookDatabase instance;

    private Map<Integer, String> books;
    private BookDatabase(){
        books = new HashMap<>();

    }
    public static synchronized BookDatabase getInstance(){
        if(instance == null){
            instance = new BookDatabase();
        }
        return instance;
    }
    public void addBooks(int id, String title){
        books.put(id,title);
}
    public void removeBooks(int id){
        books.remove(id);
}
    public void viewBooks(){
        System.out.println("Books in the database:");
        for(Map.Entry<Integer, String> entry:books.entrySet()){ // represents a key-value pair in the Map

            System.out.println("Book id:" + entry.getKey() + ", Title:" + entry.getValue()); // gets the key of the bookID and the key of titleID
        }

    }
}


