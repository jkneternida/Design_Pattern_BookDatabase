package BookDB_design_pattern;

public class Database {
    public static void main(String[] args) {
        BookDatabase database = BookDatabase.getInstance();
        database.addBooks(1,"Lord of the Rings");
        database.addBooks(2,"The Hobbit");
        database.addBooks(3, "Harry Potter and the Sorcerer's Stone");
        database.viewBooks();
        System.out.println("----------------------------");
        database.removeBooks(2);
        database.viewBooks();
    }
}
